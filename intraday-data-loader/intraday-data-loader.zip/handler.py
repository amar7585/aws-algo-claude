"""
Intraday Data Loader - AWS Lambda function

Keeps algo.candle_5min, algo.candle_15min and algo.candle_1hr current for
NIFTY and the current-month NIFTY future.

THE ONLY CRON IN THE INTRADAY PLANE. Runs every 15 minutes from 09:45 to
15:30 IST on weekdays, plus one closing sweep at 15:35 - 25 invocations a
trading day. When its candles are committed it invokes
intraday-market-sentiment, which chains to market-classifier, pattern-detector
and then strategy-manager: one schedule drives the whole chain rather than each
function guessing how long the step before it takes. See dispatch.py.

EVERY-15 DOES NOT THIN THE SERIES. The fetch window runs from midnight of the
newest stored day, not a single bar, so a run at 10:15 re-collects every bucket
of the session so far - 10:00, 10:05 and 10:10 included - in one call. See
fetch_window() for why it starts at midnight. Which intervals a given run
fetches is decided by the clock:

    fetch interval I when (run time - 09:15) is a whole multiple of I minutes

so 10:30 fetches 5 and 15, and 10:15 fetches all three - the hourly buckets
start at 09:15 and so fall due at 10:15, 11:15 ... 15:15, every one of them on
the 15-minute grid. That single rule reproduces the session-aligned boundaries
rather than restating them as a table of times that can drift out of step with
the data. The 15:35 sweep is the one explicit exception: it fetches everything
so that the last bars of the session are finalised.

PARTIAL CANDLES ARE STORED DELIBERATELY. Dhan returns the in-progress bucket,
and this function writes it. A bar is therefore correct-so-far rather than
final, and is corrected by the primary-key upsert on a later pass. Only the
newest bar per table is ever partial, so historical reads stay replayable.
Consumers distinguish the two with no extra column:

    a bar is closed  iff  candle_ts + interval_seconds <= now

Writes only to Neon project "AI Trader APP" (nameless-mountain-15353651),
database Algo, schema algo.

Modules:
    config.py   this function's tunables
    params.py   the Dhan token and client id (named params, not secrets -
                secrets.py at the zip root shadows the stdlib one)
    dhan.py     charts + expiry client, and the measured facts about them
    db.py       Neon access and the upsert
    dispatch.py handing the session on to intraday-market-sentiment

Epoch/IST handling, the Neon connection and the shared connection-string read
come from the neon-access layer.
"""

import datetime
import logging
import time

from neon_access import IST, connect, ist_datetime, read_neon_connection_string

from config import (
    CLOSING_SWEEP,
    COLD_START_DAYS,
    FUTURES_COLD_START_DAYS,
    FUTURES_INSTRUMENT_TYPE,
    FUTURES_SYMBOL_TEMPLATE,
    FUTURES_UNDERLYING_SCRIP,
    FUTURES_UNDERLYING_SEG,
    INTERVAL_TABLES,
    MAX_WINDOW_DAYS,
    MONTH_ABBREVIATIONS,
    NIFTY_INSTRUMENT_TYPE,
    NIFTY_SECURITY_ID,
    SESSION_START,
)
from db import latest_candle_ts, resolve_by_symbol, resolve_instrument, upsert_candles
from dispatch import dispatch_session
from dhan import DhanClient, session_candles, to_candles
from params import read_client_id, read_token_record

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Resolved once per IST date and reused across warm invocations, so the expiry
# list is not re-fetched 68 times a day. A cold container simply resolves again.
_future_cache = {}


def _minutes(t):
    return t.hour * 60 + t.minute


def intervals_due(run_time):
    """
    Which intervals this run should fetch. See the module docstring.

    Off-grid runs - a manual invocation at 10:07, say - fall back to the
    smallest interval rather than doing nothing, so an ad-hoc call is still
    useful.
    """
    if run_time >= CLOSING_SWEEP:
        return sorted(INTERVAL_TABLES)
    offset = _minutes(run_time) - _minutes(SESSION_START)
    if offset < 0:
        return []
    due = sorted(i for i in INTERVAL_TABLES if offset % i == 0)
    return due or [min(INTERVAL_TABLES)]


def fetch_window(last_ts, now, cold_start_days):
    """
    The window to ask Dhan for.

    With nothing stored the window is a cold start, `cold_start_days` deep -
    COLD_START_DAYS for the index, the much shallower FUTURES_COLD_START_DAYS
    for the future (see config.py for why). Otherwise the window starts at IST
    MIDNIGHT OF THE DAY OF THE NEWEST STORED BAR, for three reasons:

    * A fromDate on a bucket boundary corrupts that bucket. Dhan keeps only
      data stamped STRICTLY AFTER fromDate, and on the current day it applies
      that to the 1-minute bars before bucketing - so the bucket AT fromDate
      comes back missing its first minute: volume short, open/high/low wrong,
      close untouched. Measured 2026-10-19: from 09:55 the future's 09:55 bar
      came back 42,575 against 53,365, short by exactly the 09:55 minute's
      10,790. The old window started one interval behind the newest bar and
      overwrote a correct bar with that every run - one 5-minute bar in three,
      every 15-minute bar but 09:15 and 15:15, every hourly bar but 15:15 - in
      every session from 2026-09-15 until this changed. Nothing is stamped
      00:00, so a midnight start loses nothing. See dhan.py for the
      measurements.

    * The newest stored bar MAY BE PARTIAL. Every run re-fetches the whole
      day, so it is finalised by the next run like any other bar.

    * Starting on the newest stored DAY rather than today is what heals a gap.
      The 09:45 run starts at the previous session's midnight, so that session
      is re-written once from a past-day fetch, and an outage of several days
      is re-filled in one call.

    A cold start begins mid-day on a past day. That is clean: on a past day
    Dhan omits the bar at fromDate rather than shortening it.

    Dhan caps an intraday window at 90 days per call and answers HTTP 400
    DH-905 past it, so the start is clamped. That also bounds the cold start,
    which is why COLD_START_DAYS cannot usefully exceed 90 without chunking the
    fetch - deliberately not built.
    """
    to_dt = now + datetime.timedelta(minutes=1)  # past days: toDate non-inclusive
    if last_ts is None:
        from_dt = to_dt - datetime.timedelta(days=cold_start_days)
    else:
        from_dt = ist_datetime(last_ts).replace(hour=0, minute=0, second=0, microsecond=0)
    floor = to_dt - datetime.timedelta(days=MAX_WINDOW_DAYS)
    return max(from_dt, floor), to_dt


def assert_alignment(candles, interval, label, from_dt, to_dt):
    """
    Every bar must start on a session-aligned bucket boundary.

    Dhan's intraday buckets run from 09:15, not from the top of the hour -
    measured, see dhan.py. The hourly trigger times in intervals_due() are
    derived from that, so if Dhan ever changed it the schedule would quietly
    fetch at the wrong moments and leave bars partial. This turns that into a
    loud failure.

    It is not the only thing that trips it. Thin history does too: a far-month
    future's 90-day backfill held a 09:16 bar on 2026-09-30 while the live grid
    was intact - see FUTURES_COLD_START_DAYS. The message names the instrument
    and the window so the two causes can be told apart from the log alone.

    WEEKEND BARS ARE EXEMPT, and stored as Dhan returns them. A special session
    on a Saturday or Sunday - Diwali Muhurat trading - has its own grid, not the
    09:15 one. Sunday 2026-11-08 came back as 5-minute bars from 14:20 to 15:25,
    and its 14:20 fifteen-minute bar failed this check on every run from the
    11-09 09:45 run onward. The fifteen-minute and hourly windows start from
    the newest stored day (11-06), so they could not get past it, and
    candle_15min and candle_1hr stopped filling. Weekday bars are checked
    exactly as before. Not covered: an afternoon Muhurat on a weekday holiday
    would still raise here - earlier years' evening sessions are dropped by
    session_candles() before they reach this check.
    """
    step = interval * 60
    origin = _minutes(SESSION_START) * 60
    exempt = {}
    for candle in candles:
        stamp = ist_datetime(candle["ts"])
        if stamp.weekday() >= 5:
            exempt[stamp.date()] = exempt.get(stamp.date(), 0) + 1
            continue
        offset = (stamp.hour * 3600 + stamp.minute * 60 + stamp.second) - origin
        if offset % step:
            raise RuntimeError(
                f"{label} {interval}-minute bar stamped {stamp:%Y-%m-%d %H:%M:%S} "
                f"is not on a bucket boundary measured from {SESSION_START:%H:%M} "
                f"(window {from_dt:%Y-%m-%d %H:%M} -> {to_dt:%Y-%m-%d %H:%M}) - "
                f"either Dhan's interval alignment has changed, or the window "
                f"reaches thin, illiquid history such as a far-month future "
                f"before it became current"
            )
    for day, count in sorted(exempt.items()):
        logger.info(
            "%s %sm: %d bar(s) on %s (%s) kept without the alignment check",
            label, interval, count, day, day.strftime("%A"),
        )


def current_future_symbol(client, today):
    """
    The trading symbol of the current-month NIFTY future, derived from the
    live expiry list - nothing about the contract is hardcoded.

    The nearest option expiry's MONTH is the current futures month, and it
    rolls itself: once September's monthly expiry has passed, the nearest
    expiry is already in October. Measured 2026-09-11.
    """
    if _future_cache.get("date") == today:
        return _future_cache["symbol"]

    raw = client.expiry_list(FUTURES_UNDERLYING_SCRIP, FUTURES_UNDERLYING_SEG)
    upcoming = sorted(
        d for d in (datetime.date.fromisoformat(str(x)[:10]) for x in raw) if d >= today
    )
    if not upcoming:
        raise RuntimeError(
            f"every expiry Dhan returned is before {today}: {raw!r} - cannot "
            f"resolve the current-month future"
        )
    nearest = upcoming[0]
    symbol = FUTURES_SYMBOL_TEMPLATE.format(
        month=MONTH_ABBREVIATIONS[nearest.month - 1], year=nearest.year
    )
    logger.info("nearest expiry %s -> current future %s", nearest, symbol)
    _future_cache.update(date=today, symbol=symbol)
    return symbol


def refresh(conn, client, instrument, interval, now, cold_start_days):
    """Fetch and store one instrument at one interval."""
    table = INTERVAL_TABLES[interval]
    last_ts = latest_candle_ts(conn, instrument, table)
    from_dt, to_dt = fetch_window(last_ts, now, cold_start_days)
    mode = (
        f"resume from {from_dt:%Y-%m-%d %H:%M}"
        if last_ts
        else f"cold start {cold_start_days}d"
    )

    candles = session_candles(
        to_candles(client.intraday_candles(instrument, interval, from_dt, to_dt))
    )
    assert_alignment(candles, interval, instrument["trading_symbol"], from_dt, to_dt)
    written = upsert_candles(conn, instrument, table, candles)
    logger.info(
        "%s %sm: %s -> %d candles, %d written",
        instrument["trading_symbol"], interval, mode, len(candles), written,
    )
    return written


def lambda_handler(event, context):
    event = event or {}
    now = (
        datetime.datetime.fromisoformat(event["now"]).replace(tzinfo=IST)
        if event.get("now")
        else datetime.datetime.now(IST)
    )
    today = now.date()

    # Weekend gate. A holiday needs none: the fetch returns nothing new and
    # nothing is written.
    if today.weekday() >= 5:
        logger.info("%s is a %s - not a trading day", today, today.strftime("%A"))
        return {"status": "skipped_non_trading_day", "date": today.isoformat()}

    intervals = event.get("intervals") or intervals_due(now.time())
    if not intervals:
        logger.info("%s is before the session - nothing due", now.strftime("%H:%M"))
        return {"status": "skipped_outside_session", "time": now.strftime("%H:%M")}

    started = time.monotonic()
    record = read_token_record()
    client = DhanClient(record["access_token"])
    conn = connect(read_neon_connection_string())
    written = {}
    try:
        # The index is resolved and stored FIRST, and each interval commits as
        # it goes. The future needs an extra API call to resolve, and if that
        # call fails the exception still propagates - but the index candles
        # are already committed rather than lost alongside it.
        nifty = resolve_instrument(conn, NIFTY_SECURITY_ID, NIFTY_INSTRUMENT_TYPE)
        for interval in intervals:
            written[f"{nifty['trading_symbol']}/{interval}m"] = refresh(
                conn, client, nifty, interval, now, COLD_START_DAYS
            )

        # Only the expiry call needs the client id, and the index candles are
        # committed by now - so a missing one raises here rather than before
        # anything was written.
        client.use_client_id(read_client_id(record))
        future = resolve_by_symbol(
            conn, current_future_symbol(client, today), FUTURES_INSTRUMENT_TYPE
        )
        # A new contract after each monthly roll has no stored bars, so its
        # first run here is a cold start - kept shallow; see config.py.
        for interval in intervals:
            written[f"{future['trading_symbol']}/{interval}m"] = refresh(
                conn, client, future, interval, now, FUTURES_COLD_START_DAYS
            )

        elapsed = time.monotonic() - started
        summary = {
            "date": today.isoformat(),
            "time": now.strftime("%H:%M"),
            "intervals": intervals,
            "rows_written": sum(written.values()),
        }
        logger.info(
            "done in %.1fs: intervals %s, %d rows",
            elapsed, intervals, sum(written.values()),
        )

        # Committed, so the chain can start. Invoked last and never before the
        # writes: the upsert makes a retry rewrite identical rows, whereas
        # dispatching first could hand the snapshot a session whose candles
        # were never stored. A failure here raises with the rows already safe.
        dispatched = dispatch_session(summary)

        return {
            "status": "success",
            **summary,
            "detail": written,
            "dispatched_to": dispatched,
            "elapsed_seconds": round(elapsed, 2),
        }
    finally:
        # Any exception propagates - Lambda must record an error. Never return
        # a {"statusCode": 500} shape; Lambda counts that as a success.
        try:
            conn.close()
        except Exception:
            pass
