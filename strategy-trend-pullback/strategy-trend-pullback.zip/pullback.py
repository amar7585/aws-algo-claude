"""
The trend-day pullback setup, as a pure function of the alert and the bars.

    evaluate(detection, index_bars, daily) -> {"status": "candidate" | "stand_down", ...}

WHAT IT IS (Amar, 2026-11-09). On a trend day - the classifier's day_trend is up
or down - a key level (PDH/PDL/ORH/ORL) has been broken in the trend's direction
and price comes back to it and HOLDS. The trade is the hold, with the trend.
Reference session 2026-11-06: PDH broken 09:45, held 10:50-12:05, then +441 to
the close. It is NOT a sweep and NOT a fade: sweeps belong to the sweep
playbook on no-trend days.

THE RULES, all on the INDEX (the chart the levels are drawn on):
  setup   v2's C2 (retest / hold) or R1 (hold candle), in the trend's direction,
          at PDH/PDL/ORH/ORL (its own level, or one within NEAR of it) - or, since
          C1 (Amar 2026-11-23), at the call wall / put wall the same way; a key
          level is preferred when an event is near both
  window  trigger candle closes 09:45-14:30
  entry   the index close of the trigger candle
  stop    S3 - exit on a 5-min close back inside the opening range: below the
          opening-range high for a long, above the opening-range low for a
          short. That is market-classifier's day_trend off line, so "trend
          off" means one thing in both (Amar, 2026-11-19, rule G: inside the
          15-min range is no trend). Nominal stop for the risk figure = that
          line minus the buffer.
  inside  a trigger candle that has itself closed back inside the opening
          range stands down - its close already turned the trend off.
  T1      the session extreme before the trigger candle; then stop to
          break-even on the remainder. None when the entry is already beyond it.
  T2      the remainder held to the 15:10 close.
No risk-reward gate: the replay found a 1.5 gate kept the worse setups.

EVERY GATE CHECK RUNS, even after one fails, so a stand-down names all its
reasons. MISSING DATA RAISES (fail loudly): an alert whose trigger candle,
opening range or daily levels are absent cannot be judged, and a quiet
stand-down would hide it.

Replay (78 sessions, 88 holds): on days that ended as trends that way, S3 was
never stopped before T1 (32 of 47 reached it); on days that did not, it lost.
The trend read itself is right about half the time - that, not the stop, is
this playbook's risk. Rule G replay (86 sessions to 2026-11-19, from the deployed
zips): 165 candidates, +1556 points, profit factor 1.90, max drawdown -336, of
which 2 had closed back inside the range (-6, now stood down); option F, live for
one evening before it: 273 / +3472 / 1.86 / -1340, 82 of them inside the range.
"""

import statistics

from config import (
    HOLD_FAMILIES,
    HOLD_LEVELS,
    KEY_LEVELS,
    STOP_BUFFER_LOOKBACK_BARS,
    STOP_BUFFER_PCT,
    STOP_BUFFER_RANGE_FACTOR,
    WINDOW_FROM_MINUTE,
    WINDOW_TO_MINUTE,
)

UP, DOWN = "up", "down"
BAR_SECONDS = 300
IST_OFFSET_SECONDS = 19800
SESSION_OPEN_MINUTE = 9 * 60 + 15
ORB_END_MINUTE = 9 * 60 + 30


def ist_minute(ts):
    return ((int(ts) + IST_OFFSET_SECONDS) % 86400) // 60


def clock(ts):
    m = ist_minute(ts)
    return f"{m // 60:02d}:{m % 60:02d}"


def key_level(detection):
    """The alert's hold level: a KEY level first (its own, else the first within NEAR of it) - exactly as before C1 -
    then, since C1 (2026-11-23), an option wall the same way. None = not this playbook's level."""
    own, near = detection.get("level"), detection.get("other_levels") or ()
    for levels in (KEY_LEVELS, HOLD_LEVELS):
        if own in levels:
            return own
        hit = next((x for x in near if x in levels), None)
        if hit is not None:
            return hit
    return None


def gate(detection):
    """Every reason this alert is not this playbook's setup (empty = it is)."""
    reasons = []
    trend, direction, family = detection.get("day_trend"), detection.get("direction"), detection.get("family")
    if trend not in (UP, DOWN):
        reasons.append(f"day trend is {trend!r} - this playbook runs on trend days only")
    elif direction != trend:
        reasons.append(f"{direction} alert against the {trend} day trend")
    if family not in HOLD_FAMILIES:
        reasons.append(f"{family} is not a hold ({'/'.join(HOLD_FAMILIES)}) - breaks and sweeps are not traded here")
    if key_level(detection) is None:
        reasons.append(f"at {detection.get('level')} - not PDH/PDL/ORH/ORL or a call / put wall")
    close_minute = ist_minute(int(detection["trigger_ts"]) + BAR_SECONDS)
    if not WINDOW_FROM_MINUTE <= close_minute <= WINDOW_TO_MINUTE:
        reasons.append(f"trigger candle closes {clock(int(detection['trigger_ts']) + BAR_SECONDS)}, "
                       f"outside {clock(WINDOW_FROM_MINUTE * 60 - IST_OFFSET_SECONDS)}-"
                       f"{clock(WINDOW_TO_MINUTE * 60 - IST_OFFSET_SECONDS)}")
    return reasons


def levels(bars, daily):
    """PDH/PDL from the daily read, ORH/ORL from today's 09:15-09:25 index candles. Raises when absent."""
    if not isinstance(daily, dict) or daily.get("pd_high") is None or daily.get("pd_low") is None:
        raise RuntimeError("no daily read with pd_high / pd_low - PDH/PDL cannot be placed")
    if daily.get("stale"):
        raise RuntimeError(f"daily read for trade_date {daily.get('trade_date')} is stale - "
                           f"its pd_high / pd_low would be an older session's")
    orb = [b for b in bars if SESSION_OPEN_MINUTE <= ist_minute(b["ts"]) < ORB_END_MINUTE]
    if sorted(ist_minute(b["ts"]) for b in orb) != [SESSION_OPEN_MINUTE, SESSION_OPEN_MINUTE + 5, SESSION_OPEN_MINUTE + 10]:
        raise RuntimeError(f"opening range incomplete: index candles at {[clock(b['ts']) for b in orb]}")
    return {"pdh": float(daily["pd_high"]), "pdl": float(daily["pd_low"]),
            "orh": max(float(b["high"]) for b in orb), "orl": min(float(b["low"]) for b in orb)}


def evaluate(detection, index_bars, daily):
    reasons = gate(detection)
    if reasons:
        return {"status": "stand_down", "reasons": reasons}

    bars = sorted(({k: (int(v) if k == "ts" else float(v)) for k, v in b.items() if k in ("ts", "open", "high", "low", "close")}
                   for b in index_bars), key=lambda b: b["ts"])
    trigger_ts = int(detection["trigger_ts"])
    i = next((n for n, b in enumerate(bars) if b["ts"] == trigger_ts), None)
    if i is None:
        raise RuntimeError(f"the trigger candle {clock(trigger_ts)} is not in index_bars "
                           f"({len(bars)} candles, last {clock(bars[-1]['ts']) if bars else '-'})")
    lv = levels(bars, daily)
    up = detection["direction"] == UP
    sign = 1 if up else -1
    trigger = bars[i]
    entry = trigger["close"]
    key = key_level(detection)
    last = bars[max(0, i + 1 - STOP_BUFFER_LOOKBACK_BARS):i + 1]
    buffer = max(entry * STOP_BUFFER_PCT / 100,
                 STOP_BUFFER_RANGE_FACTOR * statistics.fmean(b["high"] - b["low"] for b in last))
    # The day trend's off line (market-classifier trend.off_lines, rule G): the
    # opening range itself - a close back inside it is no trend. The same strict
    # comparison as the classifier: a close exactly on the range high keeps an up
    # day up.
    off_line, off_name = (lv["orh"], "ORH") if up else (lv["orl"], "ORL")
    if (entry < off_line) if up else (entry > off_line):
        return {"status": "stand_down",
                "reasons": [f"the {clock(trigger_ts)} candle closed {entry:.2f}, back inside the opening range "
                            f"({lv['orl']:.2f} - {lv['orh']:.2f}) - no trend there, so no trend trade"]}
    nominal = off_line - sign * buffer
    risk = (entry - nominal) * sign
    prior = bars[:i]
    t1 = (max(b["high"] for b in prior) if up else min(b["low"] for b in prior)) if prior else None
    t1_room = None if t1 is None else (t1 - entry) * sign
    if t1_room is not None and t1_room <= 0:
        t1, t1_room = None, None
    return {
        "status": "candidate",
        "side": "LONG" if up else "SHORT",
        "trigger_ts": trigger_ts,
        "entry": entry,
        "key_level": key,
        # a key level's price as before; a wall that is the event's own level: its strike; a wall only near: unknown
        "key_price": lv[key] if key in lv else (
            float(detection["level_strike"]) if detection.get("level") == key and detection.get("level_strike") is not None
            else None),
        "levels": lv,
        "off_line": off_line,
        "off_line_name": off_name,
        "buffer": buffer,
        "stop_nominal": nominal,
        "risk": risk,
        "t1": t1,
        "t1_room": t1_room,
        "rr": None if t1_room is None else t1_room / risk,
    }
